//Sumbit Review

function submitReview() {


    var t1 = document.getElementById('text1').value;

    var t2 = document.getElementById('text2').value;

    var date = new Date();
    var options = { month: 'short', day: 'numeric', year: 'numeric' };
    var formattedDate = date.toLocaleDateString('en-US', options);
    document.getElementById('d').innerHTML = t1 + "<br>" + "  -  " + formattedDate + "<br><hr> Diving location: " + t2;
}

document.addEventListener("DOMContentLoaded", function() {

    const map = L.map('map').setView([0, 0], 2);

    // Add OpenStreetMap tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
    }).addTo(map);


    const greatBarrierReefCoords = [
        [-18.2871, 147.6992],
        [-18.2871, 150.6992],
        [-20.2871, 150.6992],
        [-20.2871, 147.6992],
        [-18.2871, 147.6992]
    ];


    L.polygon(greatBarrierReefCoords, {
        color: 'green',
        fillColor: '#32CD32',
        fillOpacity: 0.5
    }).addTo(map).bindPopup('Great Barrier Reef');

    // Add markers
    L.marker([0, 0]).addTo(map).bindPopup('<a href="https://www.youtube.com/watch?v=m9vRFoLbVDE"> Placeholder for testing </a>');
    L.marker([3.2028, 73.2207]).addTo(map).bindPopup('<a href="https://www.manta-divers.com/"> Manta Divers - Maldives </a>');

    // Add markers
    L.marker([17.30991491894327, -87.55490879810667]).addTo(map).bindPopup('<a href="https://www.youtube.com/watch?v=e0Dswnxaaho> BELIZE | Scuba Diving Lighthouse Reef Atoll </a>');

    const coolcode = [
        [-20, 152],
        [-20, 150],
        [-30, 260],
        [-30, 270],
        [-20, 152]
    ];

    // Add coolcode polygon
    L.polygon(coolcode, {
        color: 'purple',
        fillColor: 'purple',
        fillOpacity: 0.5
    }).addTo(map).bindPopup('<a href="https://www.youtube.com/watch?v=quGvnupaKoc"> Aqqq </a>');

    // Fetch and add Texas GeoJSON
    fetch('https://raw.githubusercontent.com/PublicaMundi/MappingAPI/master/data/geojson/us-states.geojson')
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            const texas = data.features.find(feature => feature.properties.name === "Texas");
            if (texas) {
                L.geoJSON(texas, {
                    style: {
                        color: 'blue',
                        fillColor: '#add8e6',
                        fillOpacity: 0.5
                    }
                }).addTo(map).bindPopup('<strong>Texas Outline</strong>');
            } else {
                console.error('Texas feature not found in GeoJSON data.');
            }
        })
        .catch(error => {
            console.error('Error fetching GeoJSON:', error);
        });

    // Location getter
    document.getElementById('getLocationBtn').addEventListener('click', function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition, showError);
        } else {
            document.getElementById('location').textContent = "Geolocation is not supported by this browser.";
        }
    });

    function showPosition(position) {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;

        // Add a marker for the user's location
        L.marker([latitude, longitude]).addTo(map)
            .bindPopup(`Your Location:<br>Latitude: ${latitude}<br>Longitude: ${longitude}`)
            .openPopup();

        // Optionally display the coordinates in a div
        document.getElementById('location').textContent = `Latitude: ${latitude}, Longitude: ${longitude}`;
    }

    function showError(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                document.getElementById('location').textContent = "User denied the request for Geolocation.";
                break;
            case error.POSITION_UNAVAILABLE:
                document.getElementById('location').textContent = "Location information is unavailable.";
                break;
            case error.TIMEOUT:
                document.getElementById('location').textContent = "The request to get user location timed out.";
                break;
            case error.UNKNOWN_ERROR:
                document.getElementById('location').textContent = "An unknown error occurred.";
                break;
        }
    }


    // Initialize review variable
    let wq1 = null;

    // Submit review function
    window.submitReview = function() {
        if (wq1 === null) {
            wq1 = prompt("In order to send a message, you must enter your email to verify (Also please don't send an innapropriate or false messages that aren't helpful, this website depends on people being honest and truthful so consider the messages that you choose to send!):");
            if (!wq1) {
                document.getElementById("d").innerHTML = "You entered an invalid or blank email. Please try again.";
                return; // Exit the function if no name is entered
            }
        }

        const t1 = document.getElementById('text1').value;
        const t2 = document.getElementById('text2').value;
        const t3 = document.getElementById('text3').value;

        const date = new Date();
        const options = { month: 'short', day: 'numeric', year: 'numeric' };
        const formattedDate = date.toLocaleDateString('en-US', options);

        document.getElementById('d').innerHTML =
            `<strong>${t1}</strong><br> - ${formattedDate}<br><hr>
             Diving location: ${t2}<br>Main Takeaways: ${t3}`;

        // Clear the input fields after submission
        document.getElementById('text1').value = '';
        document.getElementById('text2').value = '';
        document.getElementById('text3').value = '';
    };

    //location getter
    document.getElementById('getLocationBtn').addEventListener('click', function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition, showError);
            L.marker(showPosition, showError).addTo(map).bindPopup('<a href="https://www.youtube.com/watch?v=m9vRFoLbVDE"> Placeholder for testing </a>');
        } else {
            document.getElementById('location').textContent = "Geolocation is not supported by this browser.";
        }
    });

    function showPosition(position) {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        L.marker([latitude, longitude]).addTo(map).bindPopup(`Your Location:<br>Latitude: ${latitude}<br>Longitude: ${longitude}`).openPopup();
    }

    function showError(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                document.getElementById('location').textContent = "User denied the request for Geolocation.";
                break;
            case error.POSITION_UNAVAILABLE:
                document.getElementById('location').textContent = "Location information is unavailable.";
                break;
            case error.TIMEOUT:
                document.getElementById('location').textContent = "The request to get user location timed out.";
                break;
            case error.UNKNOWN_ERROR:
                document.getElementById('location').textContent = "An unknown error occurred.";

                break;

        }
    }

});